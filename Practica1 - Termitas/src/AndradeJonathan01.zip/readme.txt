Jonathan de Jesus Andrade Lopez
414006962
Practica 01

EL único detalle que me tope fue que al intentar compilar con ant desde OSX
la codificación del archivo y los acentos no me permitia compilar,
se soluciono agregando  el traibuto  encoding="UTF-8" a:

 <javac includeantruntime="false"  encoding="UTF-8" srcdir="${src.dir}" destdir="${classes.dir}" classpathref="classpath"/>

